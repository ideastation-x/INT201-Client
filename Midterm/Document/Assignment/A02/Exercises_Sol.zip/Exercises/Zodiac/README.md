# Zodiac
- Write a program to find out the Chinese Zodiac sign for a given year.