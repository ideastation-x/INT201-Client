# String Menu

## ให้เขียนโปรแกรมเพื่อทำเมนูให้เลือกกับการจัดการ Text String

- ให้เขียน Function เพื่อแสดงเมนูให้เลือกในการจัดการ String

  - 1: Reverse String
  - 2: Replace Vowels with ‘\*’
  - 3: Count Vowels in String

- ตัวอย่างเช่น “Hello World”
  - กด 1 ได้ “dlroW olleH”
  - กด 2 ได้ “H*ll* W\*rld”
  - กด 3 ได้ 3
