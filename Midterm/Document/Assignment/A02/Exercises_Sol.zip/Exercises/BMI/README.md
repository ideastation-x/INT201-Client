# BMI

- Write a program to find out the Body Mass Index in kilogram divided by the square of body height in meters
